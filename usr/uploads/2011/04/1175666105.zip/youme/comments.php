<div class="comments">
	<?php $this->comments()->to($comments); ?>
	
	<h4><?php $this->commentsNum(_t('当前暂无评论'), _t('仅有一条评论'), _t('已有 %d 条评论')); ?> &raquo;</h4>
	<?php if ($comments->have()): ?>
	<?php $comments->pageNav(); ?>
	
	<?php $comments->listComments(); ?>
	
	<?php endif; ?>

	<?php if($this->allow('comment')): ?>
	<div id="<?php $this->respondId(); ?>" class="respond">
	
	<div class="cancel-comment-reply">
	<?php $comments->cancelReply(); ?>
	</div>
	
	<h4 id="response"><?php _e('添加新评论'); ?> &raquo;</h4>
	<form method="post" action="<?php $this->commentUrl() ?>" id="comment_form">
		<?php if($this->user->hasLogin()): ?>
		<p>Logged in as <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a></p>
		<?php else: ?>
		<p>
			<label for="author"><?php _e('您的称呼'); ?><span class="required">（将会显示在评论中）*</span></label><br/>
			<input type="text" name="author" id="author" class="text" size="15" value="<?php $this->remember('author'); ?>" />
		</p>
                		<p>
			<label for="author"><?php _e('您的邮箱'); ?><span class="required">（可选，不会被公开）</span></label><br/>
			<input type="text" name="mail" id="mail" class="text" size="15" value="<?php $this->remember('mail'); ?>" />
		</p>
		<p>
			<label for="url"><?php _e('您的网站'); ?><span class="required">（可选，将会链接到您的网站）</span></label><br/>
			<input type="text" name="url" id="url" class="text" size="15" value="<?php $this->remember('url'); ?>" />
		</p>
		<?php endif; ?>
		<p>
			<label for="url"><?php _e('您的评论'); ?><span class="required">*</span></label><br/>
			<textarea rows="5" cols="50" name="text" class="textarea"><?php $this->remember('text'); ?></textarea>
		</p>
                <p><label><input type="checkbox" name="banmail" id="banmail" value="stop" ?>千万别勾我，否则我就不告诉你“伊妹儿”有人踩你。</label></p>
		<p><input type="submit" value="<?php _e('提交评论'); ?>"  class="button" /></p>
	</form>
	</div>
	<?php else: ?>
	<h4><?php _e('评论已关闭'); ?></h4>
	<?php endif; ?>
</div>
