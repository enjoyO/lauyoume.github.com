<?php
if ($this->_archiveType == 'post') {
echo <<<LOADSCRIPT

<script type="text/javascript">
    var wumiiParams = "&num=5&mode=3&pf=Typecho";
</script>
<script type="text/javascript" id="wumiiRelatedItems" src="http://widget.wumii.com/ext/relatedItemsWidget.htm"></script>
<a href="http://www.wumii.com/widget/relatedItems.htm" style="border:0;">
    <img src="http://static.wumii.com/images/pixel.png" alt="无觅相关文章插件，快速提升流量" style="border:0;padding:0;margin:0;" />
</a>
LOADSCRIPT;
}
?>
<div id="footer">
	<p>
		<a href="<?php $this->options->feedUrl(); ?>"><?php _e('文章'); ?> RSS</a> 
		<span class="sep">•</span> 
		<a href="<?php $this->options->commentsFeedUrl(); ?>"><?php _e('评论'); ?> RSS</a>
		<span class="sep">•</span> 
		<?php if($this->user->hasLogin()): ?>
		<a href="<?php $this->options->adminUrl(); ?>"><?php _e('进入后台'); ?> (<?php $this->user->screenName(); ?>)</a>
		<span class="sep">•</span> 
		<a href="<?php $this->options->logoutUrl(); ?>"><?php _e('退出'); ?></a></li>
		<?php else: ?>
		<a href="<?php $this->options->adminUrl('login.php'); ?>"><?php _e('登录'); ?></a>
		<?php endif; ?>
<span class="sep">•</span>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F9e1dc7ca4a3166737531b79db96778a3' type='text/javascript'%3E%3C/script%3E"));
</script>
<span class="sep">•</span>
<script src="http://s21.cnzz.com/stat.php?id=3069825&web_id=3069825" language="JavaScript"></script>

	</p>
	<p>
	Copyright © 2011 <a href="<?php $this->options->siteurl(); ?>"><?php $this->options->title(); ?></a>. All rights reserved. Theme by <a href="http://simplebits.com">simplebits</a> & <a href="http://blog.176878.com">lauyoume</a>.Power by <a href="http://www.typecho.org">Typecho)))</a> . <a href="http://mediatemple.net">浙ICP备11009035号</a>.
	</p>
</div>

<?php $this->footer(); ?>
</body>
</html>
