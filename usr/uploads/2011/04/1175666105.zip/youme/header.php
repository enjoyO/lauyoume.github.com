<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="content-type" content="text/html; charset=<?php $this->options->charset(); ?>" />
<title><?php $this->archiveTitle(' &raquo; ', '', ' - '); ?><?php $this->options->title(); ?></title>

<link rel="shortcut icon" type="image/ico" href="<?php $this->options->siteUrl(); ?>favicon.ico">
<!-- 使用url函数转换相关路径 -->
<link rel="stylesheet" type="text/css" media="all" href="<?php $this->options->themeUrl('style.css'); ?>" />

<!--[if lt IE 8]>
<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE8.js"></script>
<![endif]-->

<!-- 请置于所有广告位代码之前 -->
<script type="text/javascript" src="http://cbjs.baidu.com/js/m.js"></script>

<!-- 通过自有函数输出HTML头部信息 -->
<?php $this->header(); ?>
</head>

<body class="home blog">
<div id="wrap" class="group">
	<!-- begin #nav -->
	<div id="nav">
		<div id="logo">
			<a href="<?php $this->options->siteUrl(); ?>"><p><?php $this->options->title(); ?></p></a>
		</div>
		<ul>
			<li <?php if($this->is('index')): ?> class="active"<?php endif; ?> >
				<a href="<?php $this->options->siteUrl(); ?>"><?php _e('TA的主页'); ?></a>
			</li>
			<?php $this->widget('Widget_Metas_Category_List')->to($categorys); ?>
            <?php while($categorys->next()): ?>
            <li <?php if($this->is('category', $categorys->slug)): ?> class="active" <?php endif; ?>><a href="<?php $categorys->permalink(); ?>"><?php $categorys->name(); ?></a></li>
            <?php endwhile; ?>
			
			<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
			<?php while($pages->next()): ?>
			<li <?php if($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> >
				<a href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
			</li>
			<?php endwhile; ?>
		</ul>
	</div>
	<!-- end #nav -->
	
	<!-- begin #main -->
	<div id="main" class="group">
		<!-- begin #content -->
		<div id="content">
			<!-- begin #content-inner -->
			<div id="content-inner">
				<div id="branding">
					<a href="<?php $this->options->siteUrl(); ?>" ><?php $this->options->title(); ?></a> 
					<span id="branding-tag"><?php $this->options->description() ?></span>
				</div>