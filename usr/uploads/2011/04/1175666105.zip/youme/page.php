<?php $this->need('header.php'); ?>

        <div class="article">
			<div class="article-body">
			<?php $this->content(); ?>
			</div>
		</div>
	</div><!-- end #content-inner-->
</div><!-- end #content-->
<?php $this->need('sidebar.php'); ?>

</div> <!-- end #main -->
</div> <!-- end #wrap -->
<?php $this->need('footer.php'); ?>
