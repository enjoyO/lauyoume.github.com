<div id="sidebar">

			<ul class="svr group">
		<li><a href="<?php $this->options->feedUrl(); ?>" class="b rss" target="_blank"><span>订阅RSS</span></a></li>
		<li><a href="http://www.weibo.com/lauyoume" class="b weibo" target="_blank"><span>关注新浪微博</span></a></li>
		<li><a href="http://t.qq.com/lauyoume" class="b tqq" target="_blank"><span>关注腾讯微博</span></a></li>
		<li><a href="http://www.renren.com/lauyoume" class="b renren" target="_blank"><span>关注人人</span></a></li>
	</ul>
	<ul class="aboutul">
		<li>
		<span class="about">欢迎围观！I'm lauyoume<br/>
		☑棋牌开发 ☑Android ☑Web设计<br/>
		☑PHP开发 ☑C++开发 ☑架构设计
		</span>
		</li>
		
	</ul>
	<h3><?php _e('搜一搜看'); ?></h3>
	<div class="search group">
		<form method="post" action="<?php $this->options->siteUrl(); ?>">
		<input type="text" name="s" class="s-text" size="20" onkeydown=" if(event.keyCode==13) this.submit();"/> 
		<input type="submit" class="s-button" value="" />
		</form>
	</div>
        <!--
	<h3><?php _e('新店开张'); ?></h3>
	<ul>
		<li>
                <!-- 广告位：促销
                <script type="text/javascript">BAIDU_CLB_fillSlot("154744");</script>
                </li>
	</ul> -->	
	<h3><?php _e('广而告知'); ?></h3>
	<ul class="adv">
		<li><!-- 广告位：广而告知 -->
<script type="text/javascript">BAIDU_CLB_fillSlot("164932");</script></li>
	</ul>
	<h3><?php _e('友情链接'); ?></h3>
	<ul class="links">
		<?php Links_Plugin::output("SHOW_MIX_DES"); ?>
	</ul>
</div><!-- end #sidebar -->
