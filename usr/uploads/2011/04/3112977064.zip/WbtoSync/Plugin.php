<?php
/**
 * <a href="http://www.wbto.cn/">享拍微博通</a>插件,通过享拍微博通将博文同步到微博网站.<br/>
 * 具体请登录<a href="http://www.wbto.cn/">享拍微博通</a>设置所需要的同步网站或参考<a href="http://blog.176878.com/">我的博文</a>.<br/>
 * 目前仅支持将博文标题和链接同步至各个微博.<br/>
 * 开启插件后,请先设置享拍微博通的用户名和密码.
 *
 * @package WbtoSync
 * @author lauyoume
 * @version 1.0.0 
 * @link http://blog.176878.com
 */
class WbtoSync_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Abstract_Contents')->filter = array('WbtoSync_Plugin', 'doHandler');
		return _t('请对插件进行正确设置，以使插件顺利工作！') . $error;
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){
        $cfg_user = new Typecho_Widget_Helper_Form_Element_Text('cfg_user', NULL, NULL,
                _t('享拍微博通账户'),_t('你的享拍微博通账户,不是邮箱'));
        $form->addInput($cfg_user->addRule('required', _t('享拍微博通账户')));

        $cfg_pass = new Typecho_Widget_Helper_Form_Element_Password('cfg_pass', NULL, NULL,
                _t('享拍微博通密码'),_t('你的享拍微博通密码'));
        $form->addInput($cfg_pass->addRule('required', _t('享拍微博通密码')));		
	}

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 实际处理方法
     * 
     * @param Widget_Contents_Post_Edit $content,$class
     * @return array 返回变换后的$value
     */
    public static function doHandler($content,$class)
    {
		//如果是发布文章.
		if($class->request->is("do=publish")){
			self::doFollow5($content['title'] . $content['permalink']);
		}
		return $content;
    }
	
	public static function doFollow5($status){
		
		$api_url = "http://wbto.cn/api/update.json";
		$api_key = "typecho";
		
		$options = Typecho_Widget::widget('Widget_Options')->plugin('WbtoSync');
		$username = $options->cfg_user;
		$password  = $options->cfg_pass;

		$client = Typecho_Http_Client::get();

		if ($client) {
			try {
				$client->setTimeout(5)
				->setHeader('Authorization','Basic ' . base64_encode($username.":" . $password))
				->setData(array(
					'source' => $api_key,
					'content'=>$status
				))
				->send($api_url);
				unset($client);
			} catch (Typecho_Http_Client_Exception $e) {
				continue;
			}
		}
	}
}
