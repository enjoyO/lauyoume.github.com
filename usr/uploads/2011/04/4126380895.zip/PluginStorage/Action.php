<?php

class PluginStorage_Action extends Typecho_Widget implements Widget_Interface_Do
{
    /**
     * 插件安装详细信息
     * @access private
     * @var string
     */
    private $msg_li;

    /**
     * 插件安装过程中目录标记
     * @access private
     * @var string
     */
    private $dir_d="";

    /**
     * 获取插件列表
     * @access public
     * @param mixed $q 列表参数 0查看本地列表 1同步服务器列表
     * @return array
     */
    public function ls($q=0)
    {
        $file=__TYPECHO_ROOT_DIR__.__TYPECHO_PLUGIN_DIR__.'/PluginStorage/list.xml';
        if(file_exists($file) && $q!=1){
            $list=@simplexml_load_file($file);
            $filetime=date("Y-m-d H:i:s",filemtime($file)+Typecho_Widget::widget('Widget_Options')->timezone);
            $list['time_local']=$filetime;
        }else{
            $host = Typecho_Widget::widget('Widget_Options')->plugin('PluginStorage')->host;
            $url=$host."list.xml";
            if($list=@simplexml_load_file($url)){
                if($q==1){
                    $this->updateList($list);
                }else{
                    self::updateList($list);
                }
                $list['time_local']=date("Y-m-d H:i:s");
            }
        }
        return $list;
    }
    /**
     * 设置表头菜单样式
     * @access public
     * @return array
     */
    public function menu_style()
    {
        if(!isset ($_GET['page']))
        {
            $menu_stl[0]='current';
        }else{
            $menu_stl[0]='';
        }
        if(isset ($_GET['page']) && $_GET['page']=='depot')
        {
            $menu_stl[1]='current';
        }else{
            $menu_stl[1]='';
        }
        if(isset ($_GET['page']) && $_GET['page']=='info')
        {
            $menu_stl[2]='current';
        }else{
            $menu_stl[2]='';
        }
        return $menu_stl;
    }
    /**
     * 安装插件
     * @param mixed $plugName 待安装的插件名称
     * @access public
     * @return json
     */
    public function fit($plugName)
    {
        $options = $this->widget('Widget_Options');
        $host = $options->plugin('PluginStorage')->host;
        $pdir='.'.__TYPECHO_PLUGIN_DIR__;
        if(file_exists($pdir.'/'.$plugName.'.php') || file_exists($pdir.'/'.$plugName.'/Plugin.php')){
            $msg="已经存在，未执行安装过程!";
        }else{
            chdir($pdir);
            $url=$host.$plugName.".xml";
            if($xml = @simplexml_load_file($url)){
                $this->searchXml($xml);
                $msg="安装成功!";
            }else{
                $msg="安装文件未找到，请检查仓库地址或者同步插件列表再试！";
            }
        }
        $arr=array('msg'=>$msg,'li'=>$this->msg_li);
        $this->response->throwJson($arr);
    }

    /**
     * 删除插件
     * @param mixed $plugName 待删除的插件名称
     * @access public
     * @return void
     */
    public function clear($plugName)
    {
        if($plugName){
            $dir='.'.__TYPECHO_PLUGIN_DIR__;
            chdir($dir);
            if(is_dir($plugName)){
                if(false==$this->delTree($plugName)){
                    $this->widget('Widget_Notice')->set(_t('插件：'.$plugName.'删除失败'), NULL, 'error');
                }else{
                    $this->widget('Widget_Notice')->set(_t('成功删除插件：'.$plugName), NULL, 'success');
                }
            }else{
                $file=$plugName.'.php';
                if(@unlink($file)){
                    $this->widget('Widget_Notice')->set(_t('成功删除插件：'.$plugName), NULL, 'success');
                }else{
                    $this->widget('Widget_Notice')->set(_t('插件：'.$plugName.'删除失败'), NULL, 'error');
                }
             }
        }else{
            $this->widget('Widget_Notice')->set(_t('插件不存在！'), NULL, 'notice');
        }
        //$this->response->goBack();
    }

    /**
     * 搜索xml生成文件
     * @param mixed $xml xml数据流
     * @access public
     * @return void
     */
    public function searchXml($xml){

        foreach($xml->children() as $fi){
            if($fi->getName()=='dir'){
                mkdir($fi['name']);
                $this->msg_li .= "创建目录：".$this->dir_d.$fi['name']."<br>";
                $this->dir_d .= $fi['name'].'/';
                chdir($fi['name']);
                $this->searchXml($fi);
            }else{
                $fp=@fopen($fi['name'],'w');
                fwrite($fp,@gzinflate(base64_decode($fi)));
                fclose($fp);
                $this->msg_li .= "生成文件：".$this->dir_d.$fi['name']."<br>";
            }
        }
        chdir('..');
    }
    /**
     * 删除目录
     * @param mixed $dir 待删除的插件目录
     * @access public
     * @return boolean
     */
    public function delTree($dir){
        chdir($dir);
        $dh=opendir('.');
        while(false !== ($et=readdir($dh))){
            if(is_file($et)){
                @unlink($et);
            }else{
                if(is_dir($et) && $et!='.' && $et!='..'){
                    $this->delTree('./'.$et);
                }
            }
        }
        closedir($dh);
        chdir('..');
        if(@rmdir($dir)){
            return true;
        }else{
            return false;
        }
    }
    /**
     * 更新本地列表缓存
     * @param mixed $xml xml数据流
     * @access public
     * @return void
     */
    public function updateList($xml)
    {
        $dir=__TYPECHO_ROOT_DIR__.__TYPECHO_PLUGIN_DIR__.'/PluginStorage';
        $fp=fopen($dir.'/list.xml','w');
        fwrite($fp,$xml->asXML());
        @fclose($fp);
        $this->widget('Widget_Notice')->set(_t('插件列表同步成功！'), NULL, 'success');
    }

    public function action()
    {
        $this->widget('Widget_User')->pass('administrator');
        $this->on($this->request->is('ls'))->ls($this->request->ls);
        $this->on($this->request->is('fit'))->fit($this->request->fit);
        $this->on($this->request->is('clear'))->clear($this->request->clear);
        $this->response->goBack();
    }

}
