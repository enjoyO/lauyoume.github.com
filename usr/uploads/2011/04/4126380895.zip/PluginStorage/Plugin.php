<?php
/**
 * 插件仓库
 * 
 * @package Plug-in Storage
 * @author df
 * @version 1.0.1
 * @link http://defe.me
 */
class PluginStorage_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        if (!ini_get('allow_url_fopen')) {
            throw new Typecho_Plugin_Exception(_t('对不起, 您的主机 allow_url_fopen 关闭, 无法在线安装插件'));
        }       
        Helper::addPanel(1, 'PluginStorage/panel.php', _t('插件仓库'), _t('在线插件管理'), 'administrator');
        Helper::addAction('plug-in-storage', 'PluginStorage_Action');
        return _t('请设置插件仓库的服务地址，以便能在线安装插件！');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
        Helper::removeAction('plug-in-storage');
        Helper::removePanel(1, 'PluginStorage/panel.php');
    }
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $host = new Typecho_Widget_Helper_Form_Element_Text('host', NULL, 'http://typecho.defe.me/plugins/',
                _t('仓库地址'), _t('请填写插件服务器地址，以“http://”开始，以“/”结束'));
        $form->addInput($host->addRule('required', _t('必须填写一个插件服务器地址')));
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    
    /**
     * 插件实现方法
     * 
     * @access public
     * @return void
     */
    public static function render()
    {
      
    }
}
