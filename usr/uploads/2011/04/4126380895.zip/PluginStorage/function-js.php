<?php if(!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<script type="text/javascript">
var text="......"
var delay=200
var i=0
var id=0
var idx
function scrollit(id){
    if(id == 0){
        document.getElementById('msg2').innerHTML=text.slice(0,i++)
        if(i>text.length){
            i=0
            idx=setTimeout("scrollit(0)",delay*2)
        }
        else idx=setTimeout("scrollit(0)",delay)
        }
    else
    {
        document.getElementById('msg2').innerHTML=""
        clearTimeout(idx)
    }
}

function Ajax(){
	var _this=this
	var getXmlHttp=function(){
    	var http_request = false;
    	if (window.XMLHttpRequest){
        	http_request = new XMLHttpRequest();
        	if (http_request.overrideMimeType){
            	http_request.overrideMimeType('text/xml');
        	}
   		}else if (window.ActiveXObject){
	        try{
	            http_request = new ActiveXObject("Msxml2.XMLHTTP");
	        }
    	    catch (e){
        	    try{
            	    http_request = new ActiveXObject("Microsoft.XMLHTTP");
	       	    }catch (e)
    	        {}
	        }
	    }
    	if (!http_request){
        	alert('Giving up :( Cannot create an XMLHTTP instance');
        	return false;
    	}
    	return http_request;
	}
 _this.post=function(ul,page){
    df = getXmlHttp();
    df.onreadystatechange = onChange;
    df.open("post",page,true);
    df.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
    df.send(ul);
 }

_this.get=function(ul){
    df = getXmlHttp();
    df.onreadystatechange = onChange;
    df.open("GET",ul,true);
    df.send(null);
}

 _this.callback=function(json){
	 alert(json);
 }

 var onChange=function(){
    if(df.readyState == 4 ){
        if(df.status == 200) {
			 json = eval('(' + df.responseText + ')');
			 _this.callback(json);
        }
    }
 }
}

function install(plugin,page){
    var ins=new Ajax()
    ins.callback=function(json){
        if(json.msg!=''){
           document.getElementById('msg1').innerHTML=json.msg
           document.getElementById('info').innerHTML=json.li
           scrollit(1)
        }else{
           alert ("json.msg")
        }
    }
    var url='fit='+plugin
    ins.post(url,page)
}

</script>
