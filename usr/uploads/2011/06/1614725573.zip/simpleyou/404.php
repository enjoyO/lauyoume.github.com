<?php $this->need('header.php'); ?>
<!-- begin #main -->
<div id="main" class="group">
	<!-- begin #content -->
	<div id="content">
		<!-- begin #content-inner -->
		<div id="content-inner">
        <div class="article post">
			<div class="article-body">
				<h2 class="group">404 - <?php _e('页面没找到'); ?></h2>
				<p>
				<form method="post" action="<?php $this->options->siteUrl(); ?>">
					<div><input type="text" name="s" class="text" size="20" /> <input type="submit" class="button" value="<?php _e('搜索'); ?>" /></div>
				</form>
				</p>
			</div>
        </div>

		</div><!-- end #content-inner-->
	</div><!-- end #content-->
	<?php $this->need('sidebar.php'); ?>
	
</div> <!-- end #main -->
</div> <!-- end #wrap -->
<?php $this->need('footer.php'); ?>
