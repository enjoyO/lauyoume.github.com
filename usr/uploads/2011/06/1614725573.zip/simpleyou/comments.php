<div class="comments">
	<?php $this->comments()->to($comments); ?>
	
	<h4><?php $this->commentsNum(_t('当前暂无评论'), _t('仅有一条评论'), _t('已有 %d 条评论')); ?> &raquo;</h4>
	<?php if ($comments->have()): ?>
	<?php $comments->pageNav(); ?>
	
	<?php $comments->listComments(); ?>
	
	<?php endif; ?>

	<?php if($this->allow('comment')): ?>
	<div id="<?php $this->respondId(); ?>" class="respond">
	
	<div class="cancel-comment-reply">
	<?php $comments->cancelReply(); ?>
	</div>
	
	<h4 id="response"><?php _e('添加新评论'); ?> &raquo;</h4>
	<form method="post" action="<?php $this->commentUrl() ?>" id="comment_form">
		<?php if($this->user->hasLogin()): ?>
		<p>Logged in as <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a></p>
		<?php else: ?>
		<p>
			<input type="text" name="author" id="author" class="text" size="15" value="<?php $this->remember('author'); ?>" />
			<label for="author"><?php _e('称呼：'); ?></label>
		</p>
        <p>
			<input type="text" name="mail" id="mail" class="text" size="15" value="<?php $this->remember('mail'); ?>" />
			<label for="author"><?php _e('邮箱：'); ?></label>
		</p>
		<p>
			<input type="text" name="url" id="url" class="text" size="15" value="<?php $this->remember('url'); ?>" />
			<label for="url"><?php _e('网站：'); ?></label>
		</p>
		<?php endif; ?>
		<div id="com-textarea">
			<textarea name="text" class="textarea"><?php $this->remember('text'); ?></textarea>		
			<input type="submit" value="<?php _e('提交评论/Ctrl + Enter'); ?>"  class="button" />
		</div>
		<label><input type="checkbox" name="banmail" id="banmail" value="stop" ?=""><?php _e('别勾我，不然就不告诉你谁围观你啦'); ?></label>
	</form>
	</div>
	<?php else: ?>
	<h4><?php _e('评论已关闭'); ?></h4>
	<?php endif; ?>
</div>
