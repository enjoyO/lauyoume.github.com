<?php
/**
 * 简而美 2.0
 * 
 * @package 简而美 2.0 
 * @author lauyoume
 * @version 2.0.0
 * @link http://blog.176878.com
 */
 
 $this->need('header.php');
 ?>
<!-- begin #main -->
<div id="main" class="group">
	<!-- begin #content -->
	<div id="content">
		<!-- begin #content-inner -->
		<div id="content-inner">
		<?php while($this->next()): ?>
		<div class="article post">
			<div class="article-body">
					<div class="group">
						<ul class="title">
							<li class="topic">
								<h2><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
							</li>
							<li class="postmeta">
							<span><?php $this->date('Y-m-d'); ?></span>
							<span class="sep">•</span>
							<span><?php $this->category(','); ?></span>
							<span class="sep">•</span>
							<span><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('暂无评论', '%d 条评论'); ?></a></span>
							<span class="sep">•</span>
							<span><?php $this->views(); ?>人浏览</span>
						</li>
						</ul>
					</div>
					<div class="entry group">					
						<?php $this->content('继续阅读...'); ?>
					</div>
					<div class="tcc">
						<span><?php _e("标签"); ?>：<?php $this->tags(', ', true, '暂无标签'); ?></span>
					</div>
			</div>
		</div>
		<?php endwhile; ?>
		<ol class="pages">
			<ol class="nav_info"><li>页码：</li></ol>
			<?php $this->pageNav(); ?>
		</ol>
	
		</div><!-- end #content-inner-->
	</div><!-- end #content-->

	<?php $this->need('sidebar.php'); ?>

</div> <!-- end #main -->
</div> <!-- end #wrap -->
<?php $this->need('footer.php'); ?>
