<?php $this->need('header.php'); ?>
<!-- begin #main -->
<div id="main" class="group">
	<!-- begin #content -->
	<div id="content">
		<!-- begin #content-inner -->
		<div id="content-inner">
			<div class="article">
				<div class="article-body">
					<div class="entry">
					<?php $this->content(); ?>
					</div>
				</div>
				<?php $this->need('comments.php'); ?>
			</div>
		</div><!-- end #content-inner-->
	</div><!-- end #content-->
	<?php $this->need('sidebar.php'); ?>
</div> <!-- end #main -->
</div> <!-- end #wrap -->
<?php $this->need('footer.php'); ?>
