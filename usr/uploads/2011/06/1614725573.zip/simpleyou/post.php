<?php
/**
 * 这是 简而美 自定义皮肤
 * 
 * @package 简而美 自定义 
 * @author lauyoume
 * @version 1.0.0
 * @link http://176878.com/blog
 */
 
 $this->need('header.php');
 ?>
		
<!-- begin #main -->
<div id="main" class="group">
	<!-- begin #content -->
	<div id="content">
		<!-- begin #content-inner -->
		<div id="content-inner">
			<div class="article post">
				<div class="article-body">
					<div class="group">
						<ul class="title">
							<li class="topic">
								<h2><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h2>
							</li>
							<li class="postmeta">
							<span><?php $this->date('Y-m-d'); ?></span>
							<span class="sep">•</span>
							<span><?php $this->category(','); ?></span>
							<span class="sep">•</span>
							<span><a href="<?php $this->permalink() ?>#comments"><?php $this->commentsNum('暂无评论', '%d 条评论'); ?></a></span>
							<span class="sep">•</span>
							<span><?php $this->views(); ?>人浏览</span>
						</li>
						</ul>
					</div>
					<div class="entry">					
						<?php $this->content(); ?>
					</div>
					<div class="tcc">
						<span><?php _e("标签"); ?>：<?php $this->tags(', ', true, '暂无标签'); ?></span>
					</div>
				<!-- 无觅-->
				<div class="wumii-hook">
					<input type="hidden" name="wurl" value="<?php $this->permalink(); ?>" />
					<input type="hidden" name="wtitle" value="<?php $this->title(); ?>" />
				</div>
				<script>
					var wumiiSitePrefix = "<?php $this->options->siteUrl(); ?>";
				</script>
				<!-- 无觅-->
				</div>
				<?php $this->need('comments.php'); ?>
			</div>
		</div><!-- end #content-inner-->
	</div><!-- end #content-->
<?php $this->need('sidebar.php'); ?>

</div> <!-- end #main -->
</div> <!-- end #wrap -->
<?php $this->need('footer.php'); ?>