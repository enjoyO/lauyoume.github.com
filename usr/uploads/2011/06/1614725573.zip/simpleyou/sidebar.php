<div id="sidebar">

	<ul class="aboutul">
		<li>
		<span class="about">欢迎围观！I'm lauyoume<br/>
		☑棋牌开发 ☑Android ☑Web设计<br/>
		☑PHP开发 ☑C++开发 ☑架构设计
		</span>
		</li>
	</ul>
	
	<h3><?php _e('广而告知'); ?></h3>
	<ul class="adv">
		<li>
			<!-- 广告位：广而告知-->
			<script type="text/javascript">BAIDU_CLB_fillSlot("164932");</script>
		</li>
	</ul>
	<h3><?php _e('随便瞄瞄'); ?></h3>
	<ul class="radom">
		<?php ArticleList_Plugin::random('<li><a href="#">{title}</a></li>'); ?>
	</ul>
	<h3><?php _e('友情链接'); ?></h3>
	<ul class="links">
		<?php Links_Plugin::output("SHOW_MIX_DES"); ?>
	</ul>
</div><!-- end #sidebar -->
