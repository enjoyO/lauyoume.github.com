<?php
/**
 * <a href="http://http://www.follow5.com/">Follow5</a>插件,通过Follow5将博文同步到微博网站.<br/>
 * 具体请登录<a href="http://www.follow5.com/">Follow5</a>设置所需要的同步网站或参考<a href="http://blog.176878.com/">我的博文</a>.<br/>
 * 开启插件后,请先设置Follow5的用户名和密码.
 * @package TEFollow5
 * @author lauyoume
 * @version 1.1.0 
 * @link http://blog.176878.com
 */
class TEFollow5_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Abstract_Contents')->filter = array('TEFollow5_Plugin', 'doHandler');
		return _t('请对插件进行正确设置，以使插件顺利工作！') . $error;
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){
        $cfg_user = new Typecho_Widget_Helper_Form_Element_Text('cfg_user', NULL, NULL,
                _t('Follow5账户'),_t('你的Follow5账户,通常为用户名、Email、手机号'));
        $form->addInput($cfg_user->addRule('required', _t('Follow5账户')));

        $cfg_pass = new Typecho_Widget_Helper_Form_Element_Password('cfg_pass', NULL, NULL,
                _t('Follow5密码'),_t('你的Follow5密码'));
        $form->addInput($cfg_pass->addRule('required', _t('Follow5密码')));

		$cfg_mode = new Typecho_Widget_Helper_Form_Element_Radio('cfg_mode',
                array( 0 => '仅新建时同步',1 => '新建和修改时同步'),'0', '选择同步的时机');
		$form->addInput($cfg_mode);
		
		$cfg_format = new Typecho_Widget_Helper_Form_Element_Textarea('cfg_format', NULL, '我刚发表了一篇博文《{title}》,链接地址：{link} .',
			_t('微博内容'), _t('标题{title}  文章链接{link}  文章摘要/内容{more}<br/>摘要/内容会被截取前120字,建议摘要/内容和标题不要混合使用..'));
        $form->addInput($cfg_format);	
	}

    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 实际处理方法
     * 
     * @param Widget_Contents_Post_Edit $content,$class
     * @return array 返回变换后的$value
     */
    public static function doHandler($content,$class)
    {
		$options = Typecho_Widget::widget('Widget_Options')->plugin('TEFollow5');
		if(get_class($class) != 'Widget_Contents_Post_Edit'){
			return $content;
		}
		if($options->cfg_mode == '1'){
			if(!$class->request->is("do=publish") 
				||($class->request->is("do=publish") && !$class->have())){
				
				return $content;
			}
			//file_put_contents('./usr/plugins/WbtoSync/cache/' . "1.txt",$class->request->do . date('H:i:s') . "\n" ,FILE_APPEND);
		}else{
			if(!$class->request->is("do=publish") 
				||($class->request->is("do=publish") && !empty($class->request->cid))){
				return $content;
			}
		}
		
		if($options->cfg_format){
			$format = $options->cfg_format;
		}else{
			$format = '我刚发表了一篇博文《{title}》,链接地址：{link} .';
		}
		
		//标题
		$title = $content['title'];
		//短链接
		$link = self::getSinaUrl($content['permalink']);
		if(strpos($format,'{more}') !== false){
			//摘要
			if(strpos($content['text'], '<!--more-->') !== false){
				$more_t = explode('<!--more-->', $content['text']);
				list($more) = $more_t;
				$more = Typecho_Common::fixHtml(Typecho_Common::cutParagraph($more));
				$more = Typecho_Common::subStr(strip_tags($more), 0, 120, '...');
			}else{
				$more = $content['text'];
				$more = Typecho_Common::fixHtml(Typecho_Common::cutParagraph($more));
				$more = Typecho_Common::subStr(strip_tags($more), 0, 120, '...');
			}
		}else{
			$more = "";
		}
		$search = array('{title}','{link}','{more}');
		$replace = array($title,$link,$more);
		$format = str_replace($search,$replace,$format);
		
		//self::log5($format);
		//file_put_contents('./usr/plugins/TEFollow5/cache/' . "1.txt",$format . "\n",FILE_APPEND);
		self::doFollow5($format);
		return $content;
    }
	public static function getSinaUrl($url)
	{
		$api_url = 'http://api.t.sina.com.cn/short_url/shorten.json';
		$api_key = '2261244958';
		$send_url = $api_url . '?source=' . $api_key . '&url_long='.urlencode($url);
		$client = Typecho_Http_Client::get();
		if ($client) {
			try {
				$client->setTimeout(5)
				->send($send_url);
				
				$result = json_decode($client->getResponseBody());
				
				unset($client);
				return $result[0]->url_short;
				
			} catch (Typecho_Http_Client_Exception $e) {
				return $url;
			}
		}
		
		return $url;
	}
	public static function doFollow5($status){
		
		$api_url = "http://api.follow5.com/api/statuses/update.json";
		//禁止乱用.否则将造成该api_key失效！！！
		$api_key = "CF70720666C6A6C5404BDDA13C24DAC51FB8AD9C5DFC26AD";
		$source = "typecho-follow5";
		
		$options = Typecho_Widget::widget('Widget_Options')->plugin('TEFollow5');
		$username = $options->cfg_user;
		$password  = $options->cfg_pass;

		$client = Typecho_Http_Client::get();

		if ($client) {
			try {
				$client->setTimeout(5)
				->setHeader('Authorization','Basic ' . base64_encode($username.":" . $password))
				->setData(array(
					'api_key' => $api_key,
					'status'=>$status,
					'source'=>$source
				))
				->send($api_url);
				$result = $client->getResponseBody();//json_decode($client->getResponseBody());
				unset($client);
				self::log5("返回结果：\n" . $result . "\n");
			} catch (Typecho_Http_Client_Exception $e) {
				self::log5("返回结果：\n" . "发送异常失败" . "\n");
				return;
			}
		}
	}
	
	public static function log5($str)
	{
		$log_file = './usr/plugins/TEFollow5/cache/log.txt';
		$date = date('Y/m/d H:i:s');
		$str = $str . $date . "\n---------------------------------------------------------\n";
		if(!file_exists($log_file)){
			file_put_contents($log_file,$str);
		}
		else{
			file_put_contents($log_file,$str,FILE_APPEND);
		}
	}
}

