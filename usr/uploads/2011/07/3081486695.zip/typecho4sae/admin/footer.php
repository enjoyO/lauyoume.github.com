<?php if(!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
    </body>
</html>
<?php
/** 注册一个初始化插件 */
Typecho_Plugin::factory('admin/footer.php')->end();
