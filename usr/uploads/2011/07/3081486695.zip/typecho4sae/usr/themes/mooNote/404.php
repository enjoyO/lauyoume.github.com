<?php $this->need('header.php'); ?>
	<div class="list" id="kites_div">
		<div class="post post_long" id="kite_915809">
				
                        <div class="postr">
  <div class="subheader">
    <div class="boxl">
          </div>

    <div class="boxr">
                      </div>

  </div>

  <div class="content">
    <div class="con" name="pre_format_915809">
没有内容.....
    </div>
  </div>

  <div class="subfooter">
    <div class="ctrlbtn clearfix">
      <div class="lbox">
      </div>

      <div class="mbox">
                              </div>

      <div class="rbox">
      </div>
    </div>

      </div>
</div>		</div>
	</div>
	<?php $this->need('footer.php'); ?>