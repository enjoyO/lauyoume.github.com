</div>

</div>
<div id="footer">
	Powered by <a href="http://www.typecho.org" target="_blank">Typecho</a>,Theme via <a href="http://bianjian.org/zh-hans/mooNote4typecho" target="_blank">mooNote</a>, All Rights Reserved
</div>
<?php $this->footer(); ?>
</body>
</html>