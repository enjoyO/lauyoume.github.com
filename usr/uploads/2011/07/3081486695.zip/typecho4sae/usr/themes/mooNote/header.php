<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php if ($this->is('index')){$this->options->title();}elseif($this->is('page')){$this->archiveTitle('','',' - ');$this->options->title();}
elseif($this->is('category')){$this->archiveTitle('','',' - ');$this->options->title();}elseif($this->is('tag')){$this->archiveTitle('','Tag: ',' - ');$this->options->title();}elseif($this->is('archive')){$this->archiveTitle('年','存档: ','月 - ');$this->options->title();}else{$this->excerpt(16, '-');$this->options->title();}?></title>
<link rel="stylesheet" type="text/css" media="all" href="<?php $this->options->themeUrl('style.css'); ?>" />
<link rel="shortcut icon" type="image/jpeg" href="<?php $this->options->themeUrl(); ?>images/icon.jpg" />
<?php $this->header(); ?>
</head>
<body>
<div id="header">
  				<div class="btns">
<a href="<?php $this->options->siteUrl(); ?>" <?php if($this->is('index')): ?> class="selected"<?php endif; ?>><?php _e('首页'); ?></a>
<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
<?php while($pages->next()): ?>
<a href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>" <?php if($this->is('page', $pages->slug)): ?> class="selected"<?php endif; ?>><?php $pages->title(); ?></a>
<?php endwhile; ?>
		</div></div>
<div id="capa">


<div class="kite clearfix">
	<div class="pagehead">

		<div class="title" id="gang_name_id"><a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a></div>
		<div class="weburl" id="gang_uri_id"><a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->siteUrl(); ?></a></div>
	</div>
	<div class="infobar">
		<div class="showpic" id="gang_photo_id"><a href="<?php $this->options->siteUrl(); ?>"><img src="<?php $this->options->themeUrl(); ?>images/bg_head.jpg" /></a></div>
		<div class="intro" id="gang_description_id"><p>
	<?php $this->options->description() ?></p>

</div>
				<div class="btnfollow"><a href="<?php $this->options->feedUrl(); ?>" id="gang_follow_id">关注</a></div>
		                                <a href="<?php $this->options->feedUrl(); ?>" title="rss订阅">
		<div class="btnrss">
                  <span>rss订阅</span>
                </div>
                </a>
	</div>