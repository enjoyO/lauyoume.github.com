<?php
/**
 * 这是 Typecho 系统的轻博客主题 mooNote
 * 
 * @package mooNote
 * @author bianjian
 * @version 1.0
 * @link http://bianjian.org/zh-hans/mooNote4typecho
 */
 
 $this->need('header.php');
 ?>

	<div class="list" id="kites_div">
		<div class="navigation">
	<span class="sp1">
				<span class="sppagehome"><a href="<?php $this->options->siteUrl(); ?>" class="ahome" title="回第一页"><span>回第一页</span></a></span>
			</span>
	<span class="sp2">
				<span class="sppage1"><?php $this->pageLink('', 'prev'); ?></span>
				<span class="sppage2">&nbsp;&nbsp;</span>
						<span class="sppage3"><?php $this->pageLink('', 'next'); ?></span>
			</span>
</div>
<?php $first = true; ?><?php while($this->next()): ?>
<div class="post<?php if($first == true) echo " post_1" ?>">
  <div class="postr">
  <div class="subheader">
    <div class="boxl">
          </div>
    <div class="boxr">
                      </div>
  </div>
  <div class="content">
    <div class="con" name="pre_format_915811">
<?php $this->content('阅读剩余部分...'); ?>

            </div>
  </div>

  <div class="subfooter">
    <div class="ctrlbtn clearfix">
      <div class="lbox">
        <span class="uname user_tag" name="userid_tag_9054"><?php $this->author(); ?></span>
        <span class="uptime"><?php $this->date('Y-n-j G:i'); ?></span>

      </div>

      <div class="mbox">
                              </div>

      <div class="rbox">
        <a href="<?php $this->permalink() ?>" class="aopen" title="展开"><span>展开</span></a>
        <a href="<?php $this->permalink() ?>#comments" class="areply" id="show_replys_915811" name="foot_toggler" title="<?php $this->commentsNum('0看法', '1看法', '%d看法'); ?>">
          <span class="atext">回复</span>

          <span class="anumber"></span>
        </a>
      </div>
    </div>

                <div class="concomment" name="foot_element" style="display:none">
    </div>
      </div>
</div></div><?php $first = false; ?><?php endwhile; ?>
<div class="navigation navbottom">
	<span class="sp1">
				<span class="sppagehome"><a href="<?php $this->options->siteUrl(); ?>" class="ahome" title="回第一页"><span>回第一页</span></a></span>
			</span>
	<span class="sp2">
				<span class="sppage1"><?php $this->pageLink('', 'prev'); ?></span>
				<span class="sppage2">&nbsp;&nbsp;</span>
						<span class="sppage3"><?php $this->pageLink('', 'next'); ?></span>
			</span>
</div>
	</div>
<?php $this->need('footer.php'); ?>