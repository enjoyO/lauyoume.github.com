<?php $this->need('header.php'); ?>
	<div class="list" id="kites_div">
		<div class="post post_long" id="kite_915809">
				
                        <div class="postr">
  <div class="subheader">
    <div class="boxl">
          </div>

    <div class="boxr">
                      </div>

  </div>

  <div class="content">
    <div class="con" name="pre_format_915809">
<?php $this->content(); ?>
    </div>
  </div>

  <div class="subfooter">
    <div class="ctrlbtn clearfix">
      <div class="lbox">
        <span class="uname user_tag" name="userid_tag_9054"><?php $this->author(); ?></span>

        <span class="uptime"><?php $this->date('Y-n-j G:i'); ?></span>
      </div>

      <div class="mbox">
                              </div>

      <div class="rbox">
        <a href="#comments" class="areply">

          <span class="atext">回复</span>
          <span class="anumber"></span>
        </a>
      </div>
    </div>

      </div>
	  	<link rel="stylesheet" type="text/css" media="all" href="<?php $this->options->themeUrl('com.css'); ?>" />
<?php $this->need('comments.php'); ?>
</div>		</div>
	</div>
	<?php $this->need('footer.php'); ?>