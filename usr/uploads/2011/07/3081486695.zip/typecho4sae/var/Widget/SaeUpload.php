<?php
/**
 * 上传动作
 *
 * @category typecho
 * @package Widget
 * @copyright Copyright (c) 2011 lauyoume
 * @license GNU General Public License 2.0
 * @version $Id$
 */

/**
 * Sae上传组件
 *
 * @author lauyoume
 * @category typecho
 * @package Widget
 */
class Widget_SaeUpload extends Widget_Abstract_Contents implements Widget_Interface_Do
{
    //上传文件目录
    const STORAGE_DOMAIN = 'upload';

    /**
     * 上传文件处理函数,如果需要实现自己的文件哈希或者特殊的文件系统,请在options表里把uploadHandle改成自己的函数
     *
     * @access public
     * @param array $file 上传的文件
     * @return mixed
     */
    public static function uploadHandle($file)
    {
		if (empty($file['name'])) {
				return false;
		}

		$fileName = preg_split("(\/|\\|:)", $file['name']);
		$file['name'] = array_pop($fileName);
		
        //获取扩展名
        $ext = '';
        $part = explode('.', $file['name']);
        if (($length = count($part)) > 1) {
            $ext = strtolower($part[$length - 1]);
        }

        if (!self::checkFileType($ext)) {
            return false;
        }
	
        //获取文件名
        $fileName = sprintf('%u', crc32(uniqid())) . '.' . $ext;
		
		$stor = new SaeStorage();
		
		$mime = Typecho_Common::mimeContentType($fileName);
		$attr  = array('type',$mime);
		if (isset($file['tmp_name'])) {
			$path = $stor->upload(self::STORAGE_DOMAIN,$fileName,$file['tmp_name'],$attr);
			if(!$path){
				return false;
			}
		} else if (isset($file['bits'])) {
			$path = $stor->write(self::STORAGE_DOMAIN,$fileName,$file['bits'],$attr);
			if(!$path){
				return false;
			}
		} else {
			return false;
		}
		
        if (!isset($file['size'])) {
			$attr = $stor->getAttr(self::STORAGE_DOMAIN,$fileName,array('length'));
            $file['size'] = $attr['length'];
        }

        //返回相对存储路径
        return array(
            'name' => $file['name'],
            'path' => $fileName,
            'size' => $file['size'],
            'type' => $ext,
            'mime' => $mime
        );
		
    }

    /**
     * 修改文件处理函数,如果需要实现自己的文件哈希或者特殊的文件系统,请在options表里把modifyHandle改成自己的函数
     *
     * @access public
     * @param array $content 老文件
     * @param array $file 新上传的文件
     * @return mixed
     */
    public static function modifyHandle($content, $file)
    {
        if (empty($file['name'])) {
            return false;
        }

        $fileName = preg_split("(\/|\\|:)", $file['name']);
        $file['name'] = array_pop($fileName);
        
        //获取扩展名
        $ext = '';
        $part = explode('.', $file['name']);
        if (($length = count($part)) > 1) {
            $ext = strtolower($part[$length - 1]);
        }

        if ($content['attachment']->type != $ext) {
            return false;
        }

		$fileName = $content['attachment']->path;
		
		$stor = new SaeStorage();
		
		$mime = $content['attachment']->mime;
		$attr  = array('type',$mime);
		
		if (isset($file['tmp_name'])) {
			$path = $stor->upload(self::STORAGE_DOMAIN,$fileName,$file['tmp_name'],$attr);
			if(!$path){
				return false;
			}
		} else if (isset($file['bits'])) {
			$path = $stor->write(self::STORAGE_DOMAIN,$fileName,$file['bits'],$attr);
			if(!$path){
				return false;
			}
		} else {
			return false;
		}
		
        if (!isset($file['size'])) {
			$attr = $stor->getAttr(self::STORAGE_DOMAIN,$fileName,array('length'));
            $file['size'] = $attr['length'];
        }
		
        //返回相对存储路径
        return array(
            'name' => $content['attachment']->name,
            'path' => $content['attachment']->path,
            'size' => $file['size'],
            'type' => $content['attachment']->type,
            'mime' => $content['attachment']->mime
        );
		
		return false;
    }

    /**
     * 删除文件
     *
     * @access public
     * @param array $content 文件相关信息
     * @return string
     */
    public static function deleteHandle(array $content)
    {
		$stor = new SaeStorage();
		$stor->delete(self::STORAGE_DOMAIN,$content['attachment']->path);
    }

    /**
     * 获取实际文件绝对访问路径
     *
     * @access public
     * @param array $content 文件相关信息
     * @return string
     */
    public static function attachmentHandle(array $content)
    {
		$stor = new SaeStorage();
		return $stor->getUrl(self::STORAGE_DOMAIN,$content['attachment']->path);
    }

    /**
     * 获取实际文件数据
     *
     * @access public
     * @param array $content
     * @return string
     */
    public static function attachmentDataHandle(array $content)
    {
		$stor = new SaeStorage();
		return $stor->read(self::STORAGE_DOMAIN,$content['attachment']->path);
    }

    /**
     * 检查文件名
     *
     * @access private
     * @param string $ext 扩展名
     * @return boolean
     */
    public static function checkFileType($ext)
    {
        $options = Typecho_Widget::widget('Widget_Options');
        return in_array($ext, $options->allowedAttachmentTypes);
    }

    /**
     * 执行升级程序
     *
     * @access public
     * @return void
     */
    public function upload()
    {
        if (!empty($_FILES)) {
            $file = array_pop($_FILES);
            if (0 == $file['error'] && is_uploaded_file($file['tmp_name'])) {
                $result = self::uploadHandle($file);

                if (false === $result) {
					$this->response->setStatus(502);
                    exit;
                } else {

                    $struct = array(
                        'title'     =>  $result['name'],
                        'slug'      =>  $result['name'],
                        'type'      =>  'attachment',
                        'status'    =>  'publish',
                        'text'      =>  serialize($result),
                        'allowComment'      =>  1,
                        'allowPing'         =>  0,
                        'allowFeed'         =>  1
                    );

                    if (isset($this->request->cid)) {
                        $cid = $this->request->filter('int')->cid;

                        if ($this->isWriteable($this->db->sql()->where('cid = ?', $cid))) {
                            $struct['parent'] = $cid;
                        }
                    }

                    $insertId = $this->insert($struct);

                    $this->db->fetchRow($this->select()->where('table.contents.cid = ?', $insertId)
                    ->where('table.contents.type = ?', 'attachment'), array($this, 'push'));

                    /** 增加插件接口 */
                    $this->pluginHandle()->upload($this);

                    $this->response->throwJson(array(
                        'cid'       =>  $insertId,
                        'title'     =>  $this->attachment->name,
                        'type'      =>  $this->attachment->type,
                        'size'      =>  $this->attachment->size,
                        'isImage'   =>  $this->attachment->isImage,
                        'url'       =>  $this->attachment->url,
                        'permalink' =>  $this->permalink
                    ));
                }
            }
        }
		$this->response->setStatus(500);
    }

    /**
     * 执行升级程序
     *
     * @access public
     * @return void
     */
    public function modify()
    {
        if (!empty($_FILES)) {
            $file = array_pop($_FILES);
            if (0 == $file['error'] && is_uploaded_file($file['tmp_name'])) {
                $this->db->fetchRow($this->select()->where('table.contents.cid = ?', $this->request->filter('int')->cid)
                    ->where('table.contents.type = ?', 'attachment'), array($this, 'push'));

                if (!$this->have()) {
                    $this->response->setStatus(404);
                    exit;
                }

                if (!$this->allow('edit')) {
                    $this->response->setStatus(403);
                    exit;
                }

                $result = self::modifyHandle($this->row, $file);

                if (false === $result) {
                    $this->response->setStatus(502);
                    exit;
                } else {

                    $this->update(array(
                        'text'      =>  serialize($result)
                    ), $this->db->sql()->where('cid = ?', $this->cid));

                    $this->db->fetchRow($this->select()->where('table.contents.cid = ?', $this->cid)
                    ->where('table.contents.type = ?', 'attachment'), array($this, 'push'));

                    /** 增加插件接口 */
                    $this->pluginHandle()->modify($this);

                    $this->response->throwJson(array(
                        'cid'       =>  $this->cid,
                        'title'     =>  $this->attachment->name,
                        'type'      =>  $this->attachment->type,
                        'size'      =>  $this->attachment->size,
                        'isImage'   =>  $this->attachment->isImage,
                        'url'       =>  $this->attachment->url,
                        'permalink' =>  $this->permalink
                    ));
                }
            }
        }

        $this->response->setStatus(500);
    }

    /**
     * 初始化函数
     *
     * @access public
     * @return void
     */
    public function action()
    {
        if ($this->user->pass('contributor', true) && $this->request->isPost()) {
            if ($this->request->is('do=modify&cid')) {
                $this->modify();
            } else {
                $this->upload();
            }
        } else {
			$this->response->setStatus(403);
        }
    }
}
