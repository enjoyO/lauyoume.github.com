
<?php $this->need('header.php');?>
<section id="wrap" class="group">
	<section id="content">
		<div id="error-404" class="notfound">
			<h2>亲，很抱歉，您要的货暂时没有了啦!</h2>
			
			<p>亲，您可以尝试通过搜索关键字或直接<a href="<?php $this->options->siteUrl();?>" title="返回首页">返回首页</a></p>
			<form id="search" method="post" action="/">
				<input type="text" name="s" class="s-keyword" onkeydown="if(event.keyCode==13) this.submit();" value="搜搜更健康..." onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value">
				<input type="submit" value="搜索" class="submit">
			</form>
			
		</div>
	</section>
</section>
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>