<?php $this->need('header.php'); ?>

<section id="wrap" class="group">
		<section id="content">
			<?php if ($this->have()): ?>
				<?php while($this->next()): ?>
					<article class="post">
						<header class="group">
							<h2>
								<?php $this->date('m'); ?>/<span class="postdate"><?php $this->date('d'); ?></span>
								<a href="<?php $this->permalink() ?>"><?php $this->title();?></a>
							</h2>
							<span class="comment-num">
								<a href="<?php $this->permalink()?>#<?php $this->respondId(); ?>" title="我有话说">+<?php $this->commentsNum("","%d")?></a>
							</span>
						</header>
						<section>
							<?php $this->content("查看全文"); ?>
						</section>
						<footer class="group">
							<div class="tag">
								<?php $this->tags('<span class="sep">•</span>', true, '暂无标签'); ?>
								<span class="sep">•</span>
								<span class="date"><?php $this->date('Y-m-d H:i'); ?></span>
							</div>
							<div class="share">
								<a href="javascript:void();" onclick="share_tsina('<?php $this->theId();?>','<?php $this->permalink();?>')" title="分享到新浪微博"><span class="jtb sina"></span></a>
								<a href="javascript:void();" onclick="share_tqq('<?php $this->theId();?>','<?php $this->permalink();?>')" title="分享到腾讯微博"><span class="jtb qq"></span></a>
							</div>	
						</footer>
					</article>
				<?php endwhile; ?>
				<nav class="pages group">
				<?php $this->pageNav("上一页","下一页"); ?>
				</nav>
			<?php else: ?>
				<div id="nocontent" class="notfound">
					<h2 class=""><?php _e('亲，暂时没有找到您要的货！'); ?></h2>
					<p>亲，您可以尝试通过搜索关键字或直接<a href="<?php $this->options->siteUrl();?>" title="返回首页">返回首页</a></p>
					<form id="search" method="post" action="/">
						<input type="text" name="s" class="s-keyword" onkeydown="if(event.keyCode==13) this.submit();" value="搜搜更健康..." onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value">
						<input type="submit" value="搜索" class="submit">
					</form>
				</div>
			<?php endif; ?>

		</section>
</section>
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>

