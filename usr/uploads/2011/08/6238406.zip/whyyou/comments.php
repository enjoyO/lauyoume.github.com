<!-- UY BEGIN -->
<div id="uyan_frame"></div>
<script type="text/javascript" id="UYScript" src="http://uyan.cc/js/iframe.js?UYUserId=2778" async=""></script>
<!-- UY END -->

<div id="comments">
	<?php $this->comments()->to($comments); ?>
	<h3 id="comment-num"><?php $this->commentsNum(_t('还没看法呢.快来抢沙发哦^_^'), _t('当前有 %d 条看法&raquo;'), _t('当前有 %d 条看法&raquo;')); ?></h3>
	<?php if ($comments->have()): ?>
	<?php $comments->listComments(array('avatarSize'=>60)); ?>
		<?php if ($comments->hasPage()): ?>
		<div class="pages group">
			<?php $comments->pageNav("上一页","下一页"); ?>
		</div>
		<?php endif; ?>
	<?php endif; ?>
	<?php if($this->allow('comment')): ?>
	<div id="<?php $this->respondId(); ?>" class="respond">
		<div class="cancel-comment-reply">
			<?php $comments->cancelReply(); ?>
		</div>
		<h3 id="response"><?php _e('有话要说'); ?> &raquo;</h3>
		<form method="post" action="<?php $this->commentUrl() ?>" id="comment_form">
			<?php if($this->user->hasLogin()): ?>
			<p class="user">
			欢迎您，<a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>。 <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a>
			<?php Smilies_Plugin::output(); ?>
			</p>
			<?php else: ?>
			<p>
				<input type="text" name="author" id="author" class="text" size="15" value="<?php $this->remember('author');?>" />
				<label for="author"><?php _e('昵称：'); ?></label>
			</p>
			
			<p>
				<input type="text" name="mail" id="mail" class="text" size="15" value="<?php $this->remember('mail'); ?>" />
				<label for="author"><?php _e('邮箱：'); ?></label>
			</p>
			<p>
				<input type="text" name="url" id="url" class="text" size="15" value="<?php $this->remember('url'); ?>" />
				<label for="url"><?php _e('网站：'); ?></label>
				<?php Smilies_Plugin::output(); ?>
			</p>
			<?php endif; ?>
			<p id="com-textarea">
				<textarea id="comment" name="text" class="textarea" onkeydown="if(event.ctrlKey&&event.keyCode==13)
{document.getElementById('c-submit').click();return false};"><?php $this->remember('text'); ?></textarea>		
				<input id="c-submit" type="submit" value="<?php _e('提交看法/Ctrl + Enter'); ?>"  class="button" />
			</p>
		</form>
	</div>
	<?php else: ?>
	<h3><?php _e('不允许说话哦^_^'); ?></h3>
	<?php endif; ?>	
</div>