<footer id="fd">
	<div id="footer-inner">
		<p class="copyright">COPYRIGHT &copy; 2011 <a href="<?php $this->options->siteUrl(); ?>" title="<?php $this->options->title(); ?>"><?php $this->options->title(); ?></a>. ALL RIGHTS RESERVED.</p>
		<p>THEME BY <a href="http://whyyou.me">Lauyoume</a>.POWER BY <a href="http://typecho.org">Typecho)))</a>. HOSTED BY <a href="http://www.ewsidc.com" rel="nofollow">EWSIDC</a>.</p>
		<p><a href="<?php $this->options->siteurl(); ?>sitemap.xml" title="站点地图">站点地图</a> <span class="sep">•</span>百度统计代码<span class="sep">•</span>CNZZ统计代码</p>
	</div>
</footer>

<?php if(!$this->is('post')) { ?>
	<div id="top_foot">
		<div id="top" class="sprite"></div>
		<div id="foot" class="sprite"></div>
	</div>
<?php } else { ?>
	<div id="top_foot">
		<div id="top" class="sprite" title="返回顶部"></div>
		<div id="tocomment" class="sprite" title="有话要说"></div>
		<div id="foot" class="sprite" title="转到底部"></div>
	</div>
<?php } ?>

<script type="text/javascript" src="<?php $this->options->themeUrl('js/theme.js'); ?>"></script>	
<?php $this->footer(); ?>
</body>
</html>
