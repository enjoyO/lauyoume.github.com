<?php
function themeConfig($form) {
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点LOGO地址'), _t('在这里填入一个图片URL地址, 以在网站标题前加上一个LOGO'));
    $form->addInput($logoUrl);
    
    $sidebarBlock = new Typecho_Widget_Helper_Form_Element_Checkbox('sidebarBlock', 
    array('ShowRecentPosts' => _t('显示最新文章'),
    'ShowRecentComments' => _t('显示最近回复'),
    'ShowCategory' => _t('显示分类'),
    'ShowArchive' => _t('显示归档')),
    array('ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowArchive'), _t('侧边栏显示'));
    
    $form->addInput($sidebarBlock->multiMode());
}

function threadedComments($comments, $options) {
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    $commentLevelClass = $comments->_levels > 0 ? ' comment-child' : ' comment-parent';
?>
	<li id="<?php $comments->theId(); ?>" class="comment-body<?php
	 if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
	?>">
	<div class="comment-parent-body group">
		<div class="comment-avatar">
			<?php $comments->gravatar($options->avatarSize, $options->defaultAvatar); ?>
		</div>
		<div class="comment-header">
			<span class="comment-author">
				<?php $options->beforeAuthor();
				$comments->author();
				$options->afterAuthor(); ?>
			</span>
			<span class="sep">发表于</span>
			<span class="comment-meta">
				<?php $options->beforeDate();
				$comments->date($options->dateFormat);
				$options->afterDate(); ?>
			</span>
			<span class="comment-reply">
			<?php $comments->reply($options->replyWord); ?>
			</span>
		</div>
		<div class="comment-content">
			<?php $comments->content(); ?>
		</div>
	</div>
	<?php if ($comments->children) { ?>
    <div class="comment-children">
        <?php $comments->threadedComments($options); ?>
    </div>
    <?php } ?>
	</li>
<?php } ?>