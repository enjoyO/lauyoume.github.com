<!DOCTYPE HTML>
<!--[if lt IE 7 ]><html class="ie ie6"> <![endif]--> 
<!--[if IE 7 ]><html class="ie ie7"> <![endif]--> 
<!--[if IE 8 ]><html class="ie ie8"> <![endif]--> 
<!--[if IE 9 ]><html class="ie ie9"> <![endif]--> 
<!--[if (gt IE 9)|!(IE)]><!--><html><!--<![endif]-->
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php $this->options->charset(); ?>" />
<title><?php if($this->is('index')): ?>
<?php $this->options->title(); ?> - <?php $this->options->description(); ?>
<?php elseif($this->is('post')): ?>
<?php $this->title() ?> - <?php $this->category(' - ', false); ?> - <?php $this->options->title(); ?>
<?php else: ?>
<?php $this->archiveTitle(' &raquo; ','',' - '); ?><?php $this->options->title(); ?>
<?php endif; ?></title>
<link rel="shortcut icon" type="image/ico" href="<?php $this->options->siteUrl(); ?>favicon.ico">
<!-- 使用url函数转换相关路径 -->

<link rel="stylesheet" type="text/css" media="all" href="<?php $this->options->themeUrl('style.css'); ?>" />
<!-- 通过自有函数输出HTML头部信息 -->

<!-- IE HTML5 -->
<!--[if lte IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>	
<!--[if IE 6]>
<script type="text/javascript" src="http://lauyoume.sinaapp.com/usr/themes/whyyou/js/DD_belatedPNG.js"></script>
<script type="text/javascript">
	DD_belatedPNG.fix('.rssfeed, img');
</script>
<![endif]-->
<meta name="UYId" content="uyan_frame" />
<?php $this->header(); ?>
</head>
<body>
<!--[if lt IE 9]>
<div class="notice">推荐使用 chrome/safari/firefox/oprea/ie9 浏览,可获得最佳体验效果！<a href="javascript:void(0);" onclick="this.parentNode.style.display='none';return false;">[关闭提示]</a></div>
<![endif]-->
<header id="hd">
		
		<div id="logo">
			<a href="<?php $this->options->siteUrl();?>" title="<?php $this->options->title(); ?>">
				<h1><?php $this->options->title();?></h1>
				<span><?php $this->options->description() ?></span>
			</a>
		</div>
		<nav id="nav">
			<ul class="group">
				<li <?php if($this->is('index')): ?> class="active"<?php endif; ?> >
					<a href="<?php $this->options->siteUrl(); ?>"><?php _e('TA的主页'); ?></a>
				</li>
				<?php $this->widget('Widget_Metas_Category_List')->to($categorys); ?>
				<?php while($categorys->next()): ?>
				<li <?php if($this->is('category', $categorys->slug)): ?> class="active" <?php endif; ?>><a href="<?php $categorys->permalink(); ?>"><?php $categorys->name(); ?></a></li>
				<?php endwhile; ?>
				
				<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
				<?php while($pages->next()): ?>
				<li <?php if($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> >
					<a href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
				</li>
				<?php endwhile; ?>
				<li>
					<a href="http://925man.taobao.com" title="我的淘宝网店" target="_blank">网店</a>
				</li>
			</ul>
		</nav>
		<!--
		<form id="search" method="post" action="http://176878.com/">
			<input type="text" name="s" class="s-keyword" onkeydown="if(event.keyCode==13) this.submit();" value="搜笑话..." onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value">
			<input type="submit" value="搜索" class="submit">
		</form>
		-->
		<a href="<?php $this->options->feedUrl(); ?>" target="_blank" title="订阅本站" class="rssfeed"><span>订阅本站</span></a><a href="http://t.whyyou.me" target="_blank" title="我的微博" class="myweibo"><span>我的微博</span></a>
</header>
