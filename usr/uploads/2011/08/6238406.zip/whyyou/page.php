<?php $this->need('header.php'); ?>
<!-- begin #main -->
<section id="wrap" class="group">
	<section id="content">
		<article class="post">
			<section>
				<?php $this->content(); ?>
			</section>
			<footer class="group">
				<div class="pageauthor">
					<?php $this->author(); ?>
					<span class="sep">•</span>
					<span class="date"><?php $this->date('Y-m-d H:i'); ?></span> 
				</div>
			</footer>
		</article>
		<?php $this->need('comments.php'); ?>
	</section>
</section>
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>
