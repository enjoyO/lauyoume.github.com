<?php $this->need('header.php');?>
<section id="wrap" class="group">
	<section id="content">
		<article class="post">
			<header class="group">
				<h2>
					<?php $this->date('m'); ?>/<span class="postdate"><?php $this->date('d'); ?></span>
					<a href="<?php $this->permalink() ?>" title="<?php $this->title();?>"><?php $this->title();?></a>
				</h2>
				<span class="comment-num">
					<a href="<?php $this->permalink()?>#<?php $this->respondId(); ?>" title="我有话说">+<?php $this->commentsNum("","%d")?></a>
				</span>
			</header>
			<section>
				<?php $this->content("查看全文"); ?>
			</section>
			<footer class="group">
				<div class="tag">
					<?php $this->tags('<span class="sep">•</span>', true, '暂无标签'); ?>
					<span class="sep">•</span>
					<span class="date"><?php $this->date('Y-m-d H:i'); ?></span>
				</div>
				<div class="share">
					<a href="javascript:void();" onclick="share_tsina('<?php $this->theId();?>','<?php $this->permalink();?>')" title="分享到新浪微博"><span class="jtb sina"></span></a>
					<a href="javascript:void();" onclick="share_tqq('<?php $this->theId();?>','<?php $this->permalink();?>')" title="分享到腾讯微博"><span class="jtb qq"></span></a>
				</div>	
			</footer>
			<nav id="prev-next" class="group">
				<?php $this->theNext('<div class="next-a"><b>下一篇:</b> %s</div>', '<div class="next-a"><b>下一篇:</b> 木有最新的了</div>'); ?>
				<?php $this->thePrev('<div class="prev-a"><b>上一篇:</b> %s</div>', '<div class="prev-a"><b>上一篇:</b> 木有最旧的了</div>'); ?>
			</nav>
		</article>
		<?php $this->need('comments.php'); ?>
	</section>
</section>
<?php $this->need('sidebar.php'); ?>
<?php $this->need('footer.php'); ?>