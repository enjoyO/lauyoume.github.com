<aside id="as">
	<div id="as-inner" class="group">
		<div class="mod">
			<div class="aboutme">
				<h3><?php _e('ABOUT ME'); ?></h3>
				<p>欢迎围观！I'm lauyoume<br/>
		☑棋牌开发 ☑Android ☑Web设计<br/>
		☑PHP开发 ☑C++开发 ☑架构设计<br/>Email: 9#whyyou.me</p>
			</div>
			<div class="radom">
				<h3><?php _e('RADOM LOOK'); ?></h3>
				<ul class="radom">
					<?php ArticleList_Plugin::random('<li><a href="{permalink}">{title}</a></li>'); ?>
				</ul>		
			</div>			
		</div>
		<div class="mod adv">
			<h3><?php _e('ADS FOR YOU'); ?></h3>
			<ul class="thedesk">
				<li>
				<!-- nuffnang -->
				<script type="text/javascript">
				nuffnang_bid = "075f63e70dfcb7fb1b72cf84c62a32b0";
				</script>
				<script type="text/javascript" src="http://synad2.nuffnang.com.cn/lmn.js"></script>
				<!-- nuffnang-->
				</li>
			</ul>
			
			<h3><?php _e('NEW REPLY'); ?></h3>
			<ul class="newreply group">
				<?php $this->widget('Widget_Comments_Recent','ignoreAuthor=true')->to($comments); ?>
				<?php if ($comments->have()): ?>
					<?php while ($comments->next()): ?>
						<li class="rp-avatar">
							<a href="<?php $comments->permalink(); ?>" title="<?php $comments->author(FALSE);?> : <?php $comments->excerpt(120); ?>" ><?php $comments->gravatar(40, NULL); ?></a>
						</li>
					<?php endwhile; ?>
					
				<?php endif;?>
			</ul>
		</div>
		<div class="mod links">
			<h3><?php _e('FRIENDLY LINK'); ?></h3>
			<div id="link-slider">
				<ul id="h-slider">
					<?php Links_Plugin::output("SHOW_MIX_DES"); ?>
				</ul>
			</div>
			<script type="text/javascript" src="<?php $this->options->themeUrl('js/slider.js');?>"></script>
			<script type="text/javascript">new slider({id:'h-slider'});</script>
		</div>
	</div>
</aside><!-- end #sidebar -->
