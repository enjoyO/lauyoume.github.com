<?php $this->need('header.php');?>
<?php if($this->is('404')){echo 'ahahahah';}?>
<section id="wrap" class="group">
	<section id="content" class="group">
        <div class="post-content group">
            <?php $this->need('sidebar.php'); ?>
            <article class="post">
                <div class="post-inner">
                    <section>
                        <p id="error-404"></p>
                        <h3>亲，很抱歉，您要的货暂时没有了啦!</h3>
                        
                        <p>亲，您可以尝试通过搜索关键字或直接<a href="<?php $this->options->siteUrl();?>" title="返回首页">返回首页</a></p>
                        <form id="search" method="post" action="/">
                            <input type="text" name="s" class="s-keyword" onkeydown="if(event.keyCode==13) this.submit();" value="搜搜更健康..." onfocus="this.value = this.value == this.defaultValue ? '' : this.value" onblur="this.value = this.value == '' ? this.defaultValue : this.value">
                            <input type="submit" value="搜索" class="submit">
                        </form>
                    </section>
                </div>
            </article>
		</div>
	</section>
</section>

<?php $this->need('footer.php'); ?>