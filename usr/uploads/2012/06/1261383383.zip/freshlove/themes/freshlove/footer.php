<footer id="fd">
    <!-- GOOGLE 广告位 -->
    <div class="gadv">
        <div class="gadv-inner">
        </div>
    </div>
    <div id="fd-inner">
        <div id="fd-nav">
        <ul class="group">
            友情链接：<a href="<?php $this->options->siteurl(); ?>sitemap.xml" title="站点地图">站点地图</a>
            <?php Links_Plugin::output("|<a href=\"{url}\" title=\"{title}\" target=\"_blank\">{name}</a></li>\n"); ?>
        </ul>
        </div>
        <div id="fd-copy">Copyright &copy; 2011-2012 <a href="<?php $this->options->siteUrl(); ?>" title="<?php $this->options->title(); ?>"><?php $this->options->title(); ?></a>. All Rights Reserved.</div>
        <div>Theme by <a href="http://whyyou.me">Lauyoume</a>.Power By <a href="http://typecho.org">Typecho)))</a></div>
    </div>
</footer>
<?php if($this->is('post') || $this->is('page') || $this->is('archive',404)):?>
<script type="text/javascript" src="<?php $this->options->themeUrl('js/one.js'); ?>"></script>
<?php else: ?>
<script src="<?php $this->options->themeUrl('js/jquery.masonry.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('js/jquery.infinitescroll.min.js'); ?>"></script>
<script type="text/javascript">
function getpath() {
    path = $('.page-navigator a.next').attr('href');
    if (path.match(/^(.*?)<?php echo $this->request->page ? $this->request->page + 1 : 2;?>(.*?$)/)) {
        if (path.match(/^(.*?page=)<?php echo $this->request->page ? $this->request->page + 1 : 2;?>(\/.*|$)/)) {
            path = path.match(/^(.*?page=)<?php echo $this->request->page ? $this->request->page + 1 : 2;?>(\/.*|$)/).slice(1);
            return path;
        }
        path = path.match(/^(.*?)<?php echo $this->request->page ? $this->request->page + 1 : 2;?>(.*?$)/).slice(1);
    }
    return path;
}
var $page = <?php echo $this->request->page ? $this->request->page : 1;?>;
var imgurl = "<?php $this->options->themeUrl('images/loader.gif'); ?>";

$(function(){
    var $tumblelog = $('#content');
    $tumblelog.find('.post').css({ opacity: 0 });
    $tumblelog.imagesLoaded( function(){
      $tumblelog.find('.post').animate({ opacity: 1 },'slow');
      $tumblelog.masonry({
        itemSelector: '.post',
        cornerStampSelector: '.fly'
      });
    });
    $tumblelog.infinitescroll({
      navSelector  : '.pages',
      nextSelector : '.page-navigator a.next',
      itemSelector : 'article.post',
      state        : {
            currPage   : $page
      },
      bufferPx:10,
      pathParse    : getpath,
      loading: {
          finishedMsg: '<em>没有更多的文章了.</em>',
          msgText: "<em>正在载入文章...</em>",
          img: imgurl
        }
      },
      function( newElements ) {
        var $newElems = $( newElements ).css({ opacity: 0 });
        $newElems.imagesLoaded(function(){
          $newElems.animate({ opacity: 1 });
          $tumblelog.masonry( 'appended', $newElems, true );
        });
      }
    );
});
</script>
<?php endif; ?>	
<?php if($this->is('post')):?>
<script type="text/javascript" src="http://lauyoume.sinaapp.com/prettify/prettify.js"></script>
<?php endif;?>
<?php $this->footer(); ?>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F34b988ebe89b9d9f1ebd96dba4277684' type='text/javascript'%3E%3C/script%3E"));
</script>
</body>
</html>
