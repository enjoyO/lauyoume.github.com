<?php
function authorAvatar($mail,$name){
	echo '<img class="avatar" src="http://www.gravatar.com/avatar/' . md5($mail) . '?s=128&r=X' .
                '&d=" alt="' . $name . '" width="128" height="128" />';
}

function cutstr($string, $length) {
    $wordscut='';
    $j=0;
    preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $string, $info);
    for($i=0; $i<count($info[0]); $i++) {
            $wordscut .= $info[0][$i];
            $j = ord($info[0][$i]) > 127 ? $j + 2 : $j + 1;
            if ($j > $length - 3) {
                    return $wordscut." ...";
            }
    }
    return join('', $info[0]);
}

function themeConfig($form) {
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点LOGO地址'), _t('在这里填入一个图片URL地址, 以在网站标题前加上一个LOGO'));
    $form->addInput($logoUrl);
    
    $sidebarBlock = new Typecho_Widget_Helper_Form_Element_Checkbox('sidebarBlock', 
    array('ShowRecentPosts' => _t('显示最新文章'),
    'ShowRecentComments' => _t('显示最近回复'),
    'ShowCategory' => _t('显示分类'),
    'ShowArchive' => _t('显示归档')),
    array('ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowArchive'), _t('侧边栏显示'));
    
    $form->addInput($sidebarBlock->multiMode());
}

function threadedComments($comments, $options) {
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    $commentLevelClass = $comments->_levels > 0 ? ' comment-child' : ' comment-parent';
?>
	<li id="<?php $comments->theId(); ?>" class="comment-body<?php
	 if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
	?>">
    <div class="comment-inner group">
    <?php $comments->gravatar($options->avatarSize, $options->defaultAvatar); ?>
    <p class="author">
    <?php $options->beforeAuthor();$comments->author();$options->afterAuthor(); ?>
    <em><?php $options->beforeDate();echo getDayAgo($comments->date->format('Y-m-d H:i:s'));$options->afterDate(); ?></em>
    <em class="comment-reply">
        <?php $comments->reply($options->replyWord); ?>
    </em>
    </p>
    <?php $comments->content();?>
	</div>
	<?php if ($comments->children) { ?>
    <div class="comment-children">
        <?php $comments->threadedComments($options); ?>
    </div>
    <?php } ?>
	</li>
<?php
}

function getDayAgo($date){
    $d = new Typecho_Date(Typecho_Date::gmtTime());
    $now = $d->format('Y-m-d H:i:s');
    $t = strtotime($now) - strtotime($date);
    if($t < 60){
        return $t . '秒前';
    }
    if($t < 3600){
        return floor($t / 60) .  '分钟前';
    }
    if($t < 86400){
        return floor($t / 3670) . '小时前';
    }
    if($t < 604800){
        return floor($t / 86400) . '天前';
    }
    if($t < 2419200){
        return floor($t / 604800) .  '周前';
    }
    if($t < 31536000 ){
        return floor($t / 2592000 ).'月前';
    }
    
    return floor($t / 31536000 ).'年前';
    
}
function indexComment($comments){
    if(!$comments->have()) return;
    $index = 0;
    while($comments->next()){
        if($index >= 3) break;
        if($comments->authorId && $comments->authorId == $comments->ownerId) continue;
        if($comments->_levels > 0) continue;
        $index++;
?>
        <li id="<?php $comments->theId(); ?>" class="comment-body">
        <div class="comment-inner group">
            <?php $comments->gravatar(32, NULL); ?>
            <p class="author"><?php $comments->author();?><em><?php echo getDayAgo($comments->date->format('Y-m-d H:i:s'));?></em></p>
            <?php $comments->content();?>
        </div>
        </li>
<?php
    }
}
?>