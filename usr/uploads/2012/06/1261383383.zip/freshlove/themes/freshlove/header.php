<!DOCTYPE HTML>
<!--[if lt IE 7 ]><html class="ie ie6"> <![endif]--> 
<!--[if IE 7 ]><html class="ie ie7"> <![endif]--> 
<!--[if IE 8 ]><html class="ie ie8"> <![endif]--> 
<!--[if IE 9 ]><html class="ie ie9"> <![endif]--> 
<!--[if (gt IE 9)|!(IE)]><!--><html><!--<![endif]-->
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php $this->options->charset(); ?>" />
<title><?php $this->archiveTitle(' &raquo; ', '', ' - '); ?><?php $this->options->title(); ?></title>
<link rel="shortcut icon" type="image/ico" href="<?php $this->options->siteUrl(); ?>favicon.ico">
<!-- 使用url函数转换相关路径 -->

<link rel="stylesheet" type="text/css" media="all" href="<?php $this->options->themeUrl('style.min.css'); ?>" />
<!-- 通过自有函数输出HTML头部信息 -->

<!-- IE HTML5 -->
<!--[if lte IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>	
<!--[if IE 6]>
<script type="text/javascript" src="http://lauyoume.sinaapp.com/usr/themes/whyyou/js/DD_belatedPNG.js"></script>
<script type="text/javascript">
	DD_belatedPNG.fix('.rssfeed, img');
</script>
<![endif]-->
<?php if($this->is('post')):?>
<link rel="stylesheet" type="text/css" media="all" href="http://lauyoume.sinaapp.com/prettify/prettify.css">
<?php endif;?>
<?php $this->header(); ?>
</head>
<body>
<header>
	<div id="top">
		<div id="top-inner">
		</div>
	</div>
	<div  id="hd">
		<div id="hd-inner">
			<div id="logo">
				<a href="<?php $this->options->siteUrl();?>" title="<?php $this->options->title(); ?>">
					<h1><?php $this->options->title();?></h1>
					<span><?php $this->options->description() ?></span>
				</a>
			</div>
			<nav id="nav">
				<ul class="group">
					<li <?php if($this->is('index')): ?> class="active"<?php endif; ?> >
						<a href="<?php $this->options->siteUrl(); ?>"><?php _e('首页'); ?></a>
					</li>

					<?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
					<?php while($pages->next()): ?>
					<li <?php if($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> >
						<a href="<?php $pages->permalink(); ?>" title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
					</li>
					<?php endwhile; ?>
					<li>
						<a href="http://www.fuancha.com" title="图说天下" target="_blank">图博</a>
					</li>
					<li>
						<a href="http://925man.taobao.com" title="我的淘宝网店" target="_blank">网店</a>
					</li>
					<li>
						<a href="http://www.xssst.com" title="小说随身听" target="_blank">听小说</a>
					</li>                    
				</ul>
			</nav>		
		</div>
	</div>
</header>