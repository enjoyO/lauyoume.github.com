<?php
/**
 * FreshLove html5
 * 
 * @package FreshLove 
 * @author lauyoume
 * @version 1.0.0
 * @link http://whyyou.me
 */
$this->need('header.php');
?>

<?php $this->need('tmp_index.php'); ?>

<?php $this->need('footer.php'); ?>
