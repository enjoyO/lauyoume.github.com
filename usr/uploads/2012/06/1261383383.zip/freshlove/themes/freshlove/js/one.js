$(document).ready(function($){
    var fdtop = $('#fd').position().top;
    $(window).scroll(function(){
        var top = $(window).scrollTop();
        var sub = top + $('.post-left').height() - fdtop;
        if( sub > 0){
            $('.post-left').css({'position':'fixed','top': '' + -sub + 'px'});
        }else if(top > 102){
            $('.post-left').css({'position':'fixed','top':'0px'});
        } 
        else{
            top = 0;
            $('.post-left').css({'position':'relative'});
        }
    });
});