<?php $this->need('header.php');?>
<section id="wrap" class="group">
	<section id="content" class="group">
        <div class="post-content group">
            <?php $this->need('sidebar.php'); ?>
            <article class="post">
                <div id="<?php $this->theId(); ?>" class="post-inner">
                    <header class="group">
                        <h2><?php $this->title();?></h2>
                        <div class="post-author group">
                            <?php echo '<img class="avatar" src="http://www.gravatar.com/avatar/' . md5($this->author->mail) . '?s=32&r=X' .
                '&d=" alt="' . $this->author->screenName . '" width="32" height="32"/>'; ?>
                        </div>
                    </header>
                    <section>
                        <?php $this->content(); ?>
                    </section>
                    <footer class="group">
                        <div class="postinfo group">
                            <p class="date"><?php $this->date('Y-m-d H:i'); ?></p>
                            <p class="posttag">
                                <?php $this->tags('<em>|</em>', true, ''); ?>
                            </p>
                        </div>
                        <nav id="prev-next" class="group">
                            <?php $this->thePrev('<div class="prev-a"><b>上一篇:</b> %s</div>', '<div class="prev-a"><b>上一篇:</b> 木有最旧的了</div>'); ?>
                            <?php $this->theNext('<div class="next-a"><b>下一篇:</b> %s</div>', '<div class="next-a"><b>下一篇:</b> 木有最新的了</div>'); ?>
                        </nav>
                    </footer>
                </div>
                <?php $this->need('comments.php'); ?>
            </article>
		</div>
	</section>
</section>

<?php $this->need('footer.php'); ?>