<?php if($this->is('post') || $this->is('page') || $this->is('archive',404)):?>
<aside class="post-left">
<?php endif; ?>
    <div class="<?php if(!($this->is('post') || $this->is('page')|| $this->is('archive',404))):?>post <?php endif;?>fly">
        <div class="post-inner group">
            <div class="cat">
            <ul>
                <li <?php if($this->is('index')): ?> class="active"<?php endif; ?> >
                    <?php if($this->is('index')): ?>
                    <span><?php _e('全部'); ?></span>
                    <?php else: ?>
                    <a href="<?php $this->options->siteUrl(); ?>"><?php _e('全部'); ?></a>
                    <?php endif; ?>
                </li>
                <?php $this->widget('Widget_Metas_Category_List')->to($categorys); ?>
                <?php while($categorys->next()): ?>
                <li <?php if($this->is('category', $categorys->slug)): ?> class="active" <?php endif; ?>>
                    <?php if($this->is('category', $categorys->slug)): ?>
                    <span><?php $categorys->name(); ?></span>
                    <?php else: ?>
                    <a href="<?php $categorys->permalink(); ?>"><?php $categorys->name(); ?></a>
                    <?php endif; ?>
                </li>
                <?php endwhile; ?>
            </ul>
            </div>
            <div class="info">
                <img class="avatar" src="<?php $this->options->themeUrl('images/avatar.jpeg'); ?>" width="168" height="168" />
                <ul class="group">
                    <li><a href="<?php $this->options->feedUrl(); ?>" class="icon1" target="_blank" title="订阅我的博客" style="text-indent: 0px; "></a></li>
                    <li><a href="http://t.qq.com/lauyoume" class="icon2" target="_blank" title="订阅我的腾讯微博" style="text-indent: 0px; "></a></li>
                    <li><a href="http://weibo.com/lauyoume" target="_blank" class="icon3" title="订阅我的新浪微博" style="text-indent: 0px; "></a></li>
                    <li><a href="http://r.qq.com/cgi-bin/reader_switch?u=http://whyyou.me/feed" target="_blank" class="icon4" title="QQ邮箱订阅" style="text-indent: 0px; "></a></li>				
                </ul>
            </div>
        </div>
    </div>    
<?php if($this->is('post') || $this->is('page') || $this->is('archive',404)):?>
    <div class="post-relate">
        <h3>您可能感兴趣的文章</h3>
    <?php if(false):?>
        <ul class="relate">
            <?php $this->related(12)->to($relatePost);?>
            <?php while ($relatePost->next()): ?>
            <li><a href="<?php $relatePost->permalink(); ?>" title="<?php $relatePost->title(); ?>"><?php echo cutstr($relatePost->title,48); ?></a></li>
            <?php endwhile; ?>
        </ul>                    
    <?php else: ?>
        <ul class="relate">
            <?php ArticleList_Plugin::random('<li><a href="{permalink}" title="{title}">{title}</a></li>'); ?>
        </ul>
    <?php endif;?>
    </div>
</aside><!-- end #sidebar -->
<?php endif; ?>
