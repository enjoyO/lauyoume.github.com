<div id="wrap" class="group">
	<section id="content" class="group">

        <?php $this->need('sidebar.php'); ?>
		<?php if ($this->have()): ?>
			<?php while($this->next()): ?>
				
				<article class="post">
					<div id="<?php $this->theId(); ?>"class="post-inner">
					<header class="group">
						<h2>
							<a href="<?php $this->permalink() ?>" title="<?php $this->title();?>"><?php $this->title();?></a>
						</h2>
					</header>
					<section>
                        <?php
                        $t = "";
                        if(preg_match('<img(.*?)src=\"(.*?)(?=\")>',$this->content,$src)){
                            $t = $src[2];
                        }
                        ?>
                        <?php if(!empty($t)): ?><p><a href="<?php $this->permalink() ?>" title="<?php $this->title();?>" rel="link"><img src="http://ithumb.sinaapp.com/?w=300&src=<?php echo $t; ?>" title="<?php $this->title();?>"/></a></p><?php endif; ?>
                        <p><?php $this->excerpt(140); ?><a href="<?php $this->permalink()?>" title="查看全文">[查看全文]</a></p>
					</section>
					<footer>
                        <div class="postinfo group">
                            <p class="date"><?php $this->date('Y-m-d H:i'); ?></p>
                            <p>
                                <a href="<?php $this->permalink()?>#comments" title="<?php $this->commentsNum("共0条评论","共%d条评论")?>"><?php $this->commentsNum("共0条评论","共%d条评论")?></a><em>|</em><a href="<?php $this->responseUrl(); ?>" title="留下你的评论">评论</a>
                            </p>
                        </div>
						<div class="postbottom">
                        <?php
                            
                            $parameter = array('parentId' => $this->cid, 'parentContent' => $this->row,
        'respondId' => $this->respondId, 'commentPage' => $this->request->filter('int')->commentPage);
                            $comments = $this->widget('Widget_Comments_Archive@' . $this->cid, $parameter);
                        ?>
                        <?php if($comments->have()):?>
                            <ul>
                                <?php indexComment($comments); ?>
                            </ul>
                        <?php endif; ?>							
						</div>	
					</footer>
					</div>
				</article>
			<?php endwhile; ?>
		<?php endif; ?>
	</section>
	<div class="clear"></div>
	<nav class="pages group">
		<?php $this->pageNav("上一页","下一页"); ?>
	</nav>
</div>